Special Source
==============

Automatic generator and renamer of jar obfuscation mappings. 